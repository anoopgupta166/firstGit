#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os

import datetime
import logging
import pandas as pd
import numpy as np
import boto3
from botocore.exceptions import ClientError
import xlsxwriter
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dateutil.relativedelta import relativedelta, SU
import json

__author__ = "Ravi Petlur, M Bilal k"
__version__ = "0.1.1"

TARGET_REGION = 'ap-south-1'


class CostExplorer:

    account_name = {'128241259851': 'LeadSquared Production', '996667749762': 'LeadSquared Dev', '509621106285': 'LSQ Connectors and Custom Work', '915224727878': 'LSQ AWS MASTER', '001453127124': 'LSQ PS Tech', '906698663397': 'LSQ Analytics V2 QA', '110724461921': 'LeadSquared Devops Portal',
                    '379483409175': 'LeadSquared Portals', '038631675249': 'LeadSquared Staging QA', '388476464677': 'LeadSquared PreSales', '877124996003': 'LSQ CAPRAS', '315470347968': 'LeadSquared Marketplace QA', '073621582683': 'Sprinkle Data - Byjus', '634463322756': 'KotakSecLeadSquared', '275174361375': 'LSQ Analytics Production', '978162671809': 'LSQ Connectors and Apps 2', '309422450306': 'LSQ Desktop App Dev QA', '820903444939': 'Sprinkle Data - Unacademy'}
    deprecated_customers = {'', 'NA', '11071', '14208', '26518', '39660', '39771', '42218', '45557', '47583', '47584', '47585', '48962', '49512', '49690', '50527', '50556', '50885', '51158', '5241', '13200', '13930', '16224', '18413', '22769', '23943', '24692', '31671', '33325', '33438', '33600', '34890', '35706', '36141', '36351', '36408', '37208', '41662', '41746', '4258', '42849', '44579', '45572', '46105', '46222', '46428', '46430', '46441', '46491', '46725', '47837', '48667', '49060', '49074', '49193', '49317', '49685', '49972', '49974', '49983', '50100', '50219', '50363', '50365', '50456', '50476', '50502', '50698', '50700', '50864', '50871',
                            '51116', '51242', '51252', '51262', '51282', '51284', '51368', '51469', '51472', '51478', '51487', '51579', '51610', '51656', '51708', '51789', '51911', '51960', '51961', '51962', '51964', '52019', '52027', '5515', '5927', '18917', '1959', '21', '32991', '33949', '34887', '36410', '38436', '40313', '40981', '45435', '46426', '46440', '46476', '46838', '47091', '48317', '48708', '48958', '48960', '48980', '49643', '50111', '50338', '50383', '50389', '50411', '50701', '50890', '51085', '51468', '51545', '51751', '51797', '51823', '51954', '51959', '51997', '52147', '52269', '52282', '52296', '52301', '52306', '52311', '52327', '52382'}
    regions = ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
               'us-gov-east-1', 'us-gov-west-1',
               'sa-east-1',
               'ca-central-1',
               'eu-central-1', 'eu-west-1', 'eu-west-2', 'eu-south-1', 'eu-west-3', 'eu-north-1',
               'af-south-1',
               'me-south-1',
               'cn-north-1', 'cn-northwest-1',
               'ap-east-1', 'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1',
               ]
    region_to_names = {
        "us-east-2": "US East",
        "us-east-1": "US East",
        "ap-southeast-1": "Singapore",
        "ap-south-1": "Mumbai",
    }

    def __init__(self):
        self.reports = []
        self.client = boto3.client('ce', region_name=TARGET_REGION)
        satdate = datetime.datetime.now() + relativedelta(weekday=SU(-1))
        self.end = satdate.date()
        self.start = (self.end - relativedelta(days=+84))
        try:
            self.accounts = self.getAccounts()
        except:
            logging.exception("Getting Account names failed")
            self.accounts = {}

    def convertRegionCodesToNames(self):
        region_dict = {
            "us-east-1": "US East",
            "us-east-2": "US East",
            "ap-southeast-1": "Singapore",
            "ap-south-1": "Mumbai",
        }
        return region_dict

    def getAccounts(self):
        accounts = {}
        client = boto3.client('organizations', region_name=TARGET_REGION)
        paginator = client.get_paginator('list_accounts')
        response_iterator = paginator.paginate()
        for response in response_iterator:
            for acc in response['Accounts']:
                accounts[acc['Id']] = acc
        return accounts

    def addReport(self, Name="Default", GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}, ], Style='Total'):
        '''
        Generate report for Account or Service
        '''
        type = 'chart'
        results = []
        Dimensions = {
            "Not": {"Dimensions": {"Key": "RECORD_TYPE",
                                   "Values": ["Tax", "Credit", "Refund", "Upfront", "Support", "EC2 Usage",
                                              #   "Out of Cycle Billing - DataTransfer",
                                              "Other out-of-cycle charges"
                                              ]}}}
        '''
        Getting data from boto3 API
        '''
        response = self.client.get_cost_and_usage(
            TimePeriod={
                'Start': self.start.isoformat(),
                'End': self.end.isoformat()

            },
            Granularity='DAILY',
            Metrics=[
                'NetAmortizedCost',
            ],
            Filter=Dimensions.copy(),
            GroupBy=GroupBy,
        )

        if response:
            results.extend(response['ResultsByTime'])
            while 'nextToken' in response:
                nextToken = response['nextToken']
                response = self.client.get_cost_and_usage(
                    TimePeriod={
                        'Start': self.start.isoformat(),
                        'End': self.end.isoformat()
                        # 'Start': '2020-03-01',
                        # 'End': '2020-04-05'
                    },
                    Granularity='DAILY',
                    Metrics=[
                        'NetAmortizedCost',
                    ],
                    GroupBy=GroupBy,
                    Filter=Dimensions.copy(),
                    NextPageToken=nextToken
                )

                results.extend(response['ResultsByTime'])
                if 'nextToken' in response:
                    nextToken = response['nextToken']
                else:
                    nextToken = False
        rows = []
        sort = ''

        if Style == 'Account':
            Cost = 0
            for v in results:
                row = {'date': v['TimePeriod']['Start']}
                for i in v['Groups']:
                    key = i['Keys'][0]
                    key = str(key) + '|' + str(self.account_name.get(key))
                    Cost = float(i['Metrics']['NetAmortizedCost']['Amount'])
                    row.update({key: round(Cost, 2)})
                rows.append(row)
            '''
            converting the json data to dataframe
            '''
            df = pd.DataFrame(rows)
            df = df.fillna(0.0)
            df['date'] = pd.to_datetime(df['date'])
            df['date'] = df['date'] - pd.DateOffset(days=6)
            df = df.groupby([pd.Grouper(key='date', freq='W-SUN')]
                            ).sum().sort_values(by='date',  ascending=False)
            df = df.T
            df.insert(0, 'WoW change (%)', '')
            pos = 1
            curr = df.columns[pos]
            pos = 2
            pre = df.columns[pos]
            df[['WoW change (%)']] = round(
                ((df[curr] - df[pre])/df[pre] * 100), 2)
            df = df.fillna(0.0)
            df[['Account #', 'Account Name']
               ] = df.index.to_series().str.split('|', expand=True)
            df.reset_index(drop=True, inplace=True)
            cols = list(df.columns)
            cols = [cols[-1]] + cols[:-1]
            cols = [cols[-1]] + cols[:-1]
            df = df[cols]
            df.sort_values(by=['Account #', 'Account Name'],
                           ascending=[True, True], inplace=True)
            type = 'table'
            self.reports.append({'Name': Name, 'Data': df, 'Type': type})

        else:
            '''
            Formatting the boto3 response data 
            '''
            for v in results:
                row = {'date': v['TimePeriod']['Start']}
                sort = v['TimePeriod']['Start']
                eccost = 0
                rediscost = 0
                ESScost = 0
                RDScost = 0

                SQSCost = 0
                S3Cost = 0
                cloudWatchCost = 0

                Othercost = 0

                for i in v['Groups']:
                    key = i['Keys'][0]
                    netAmortizedCost = float(
                        i['Metrics']['NetAmortizedCost']['Amount'])
                    if key in ['Amazon ElastiCache']:
                        rediscost = rediscost + netAmortizedCost
                        row.update({'Redis': round(rediscost, 2)})
                    elif key in ['Amazon Elasticsearch Service', 'Amazon OpenSearch Service']:
                        ESScost = ESScost + netAmortizedCost
                        row.update({'ESS': round(ESScost, 2)})
                    elif key in ['Amazon Relational Database Service']:
                        RDScost = RDScost + netAmortizedCost
                        row.update({'RDS': round(RDScost, 2)})
                    elif key in ['Amazon Elastic Compute Cloud - Compute', 'EC2 - Other',
                                 'Amazon Elastic Load Balancing']:
                        eccost = eccost + netAmortizedCost
                        row.update({'EC2': round(eccost, 2)})
                    elif key in ['EC2 Usage']:
                        print(
                            str(netAmortizedCost))
                    elif key in ['EC2 Usage']:
                        print(
                            str(netAmortizedCost))

                    elif key in ["Amazon Simple Queue Service"]:
                        SQSCost += netAmortizedCost
                        row.update({'SQS': round(SQSCost, 2)})

                    elif key in ["Amazon Simple Storage Service"]:
                        S3Cost += netAmortizedCost
                        row.update({'S3': round(S3Cost, 2)})

                    elif key in ["AmazonCloudWatch"]:
                        cloudWatchCost += netAmortizedCost
                        row.update(
                            {'cloudWatch': round(cloudWatchCost, 2)})

                    else:
                        Othercost = Othercost + netAmortizedCost
                        row.update({'Others': round(Othercost, 2)})

                rows.append(row)
                
            '''
            converting the json data to dataframe
            '''
            df = pd.DataFrame(rows)
            df['date'] = pd.to_datetime(df['date'])
            df = df.fillna(0.0)

            df = df.groupby([pd.Grouper(key='date', freq='W-SAT')]
                            ).sum().reset_index().sort_values('date')
            df.loc[:, 'Total Weekly'] = df.iloc[:, 1:6].sum(axis=1)
            df.loc[:, 'Avg Daily Cost'] = round(
                df.iloc[:, 1:6].sum(axis=1) / 7, 2)
            df.loc[:, 'Avg Hourly Cost'] = round(
                df.iloc[:, 1:6].sum(axis=1) / (7 * 24), 2)
            df.loc[:, 'Week on Week delta'] = round(
                df['Total Weekly'].pct_change() * 100, 2).fillna(0)
            df.loc[:, 'EC2 inc %'] = round(
                df['EC2'].pct_change() * 100, 2).fillna(0)
            df.loc[:, 'RDS inc %'] = round(
                df['RDS'].pct_change() * 100, 2).fillna(0)
            df.loc[:, 'ESS inc %'] = round(
                df['ESS'].pct_change() * 100, 2).fillna(0)

            df.loc[:, 'Redis inc %'] = round(
                df['Redis'].pct_change() * 100, 2).fillna(0)

            df.loc[:, 'SQS inc %'] = round(
                df['SQS'].pct_change() * 100, 2).fillna(0)

            df.loc[:, 'S3 inc %'] = round(
                df['S3'].pct_change() * 100, 2).fillna(0)

            df.loc[:, 'cloudWatch inc %'] = round(
                df['cloudWatch'].pct_change() * 100, 2).fillna(0)

            df.loc[:, 'Others inc %'] = round(
                df['Others'].pct_change() * 100, 2).fillna(0)
            df.loc[:, 'Week of'] = df['date'] - pd.DateOffset(days=6)
            df['Week of'] = pd.to_datetime(df['Week of']).dt.date
            columnsTitles = ['Week of', 'RDS', 'EC2', 'ESS', 'Redis', 'SQS', 'S3', 'cloudWatch', 'Others', 'Total Weekly', 'Avg Daily Cost',
                             'Avg Hourly Cost', 'Week on Week delta', 'RDS inc %', 'EC2 inc %', 'ESS inc %', 'Redis inc %',
                             'SQS inc %', 'S3 inc %', 'cloudWatch inc %', 'Others inc %']
            df = df.reindex(columns=columnsTitles)
            df = df.set_index(df['Week of'])
            self.reports.append({'Name': Name, 'Data': df, 'Type': type})

    # Call with Savings True to get Utilization report in dollar savings

    def addTAGReport(self, Name="Default", GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}, ],
                     Style='Total', tag=''):

        results = []
        self.tagstart = (datetime.date.today() -
                         relativedelta(months=+3)).replace(day=1)
        self.threemonth = (datetime.date.today()).replace(day=1)
        if tag == 'Purpose' and Style == 'Developer':
            Dimensions = {
                "Not": {
                    "Dimensions": {
                        "Key": "RECORD_TYPE",
                        "Values": ["Tax", "Credit", "Refund", "Upfront", "Support", "Other out-of-cycle charges"]
                    }
                }
            }
        elif tag == 'ConnectorIdentifier':
            Dimensions = {"And": [{
                "Dimensions": {
                    "Key": "LINKED_ACCOUNT",
                    "Values": ["509621106285"]
                }
            }, {
                "Not": {
                    "Dimensions": {
                        "Key": "RECORD_TYPE",
                        "Values": ["Tax", "Credit", "Refund", "Upfront", "Support", "Other out-of-cycle charges"]
                    }
                }
            }]}
        else:
            Dimensions = {"And": [{
                "Dimensions": {
                    "Key": "LINKED_ACCOUNT",
                    "Values": ["128241259851", "634463322756"]
                }
            }, {
                "Not": {
                    "Dimensions": {
                        "Key": "RECORD_TYPE",
                        "Values": ["Tax", "Credit", "Refund", "Upfront", "Support", "Other out-of-cycle charges"]
                    }
                }
            }]}
        '''
        Getting data from boto3 API
        '''
        response = self.client.get_cost_and_usage(
            TimePeriod={
                'Start': self.tagstart.isoformat(),
                'End': self.threemonth.isoformat()
            },
            Granularity='MONTHLY',
            Metrics=[
                'AmortizedCost',
            ],
            GroupBy=GroupBy,
            Filter=Dimensions.copy()
        )

        if response:
            results.extend(response['ResultsByTime'])

            while 'nextToken' in response:
                nextToken = response['nextToken']
                response = self.client.get_cost_and_usage(
                    TimePeriod={
                        'Start': self.tagstart.isoformat(),
                        'End': self.threemonth.isoformat()
                    },
                    Granularity='MONTHLY',
                    Metrics=[
                        'AmortizedCost',
                    ],
                    GroupBy=GroupBy,
                    Filter=Dimensions.copy(),
                    NextPageToken=nextToken
                )

                results.extend(response['ResultsByTime'])
                if 'nextToken' in response:
                    nextToken = response['nextToken']
                else:
                    nextToken = False
        '''
        Formatting the boto3 response data 
        '''
        rows = []
        sort = ''
        replacestring = tag + '$'
        if len(tag) == 0:
            tag = 'date'
        ceregion = CostExplorer()
        converted_regions = ceregion.convertRegionCodesToNames()
        for v in results:
            row = {tag: v['TimePeriod']['Start']}
            sort = v['TimePeriod']['Start']
            for i in v['Groups']:
                if (tag != 'date' and tag != 'Purpose') or (tag == 'Purpose' and Style == 'Developer'):
                    if tag == 'Customer':
                        if (i['Keys'][0].replace(replacestring, '') not in self.deprecated_customers):
                            if Style == 'Service':
                                key = i['Keys'][0].replace(
                                    replacestring, '') + '|' + i['Keys'][1]
                                row.update(
                                    {key: round(float(i['Metrics']['AmortizedCost']['Amount']), 2)})
                            else:
                                key = i['Keys'][0].replace(replacestring, '')
                                row.update(
                                    {key: round(float(i['Metrics']['AmortizedCost']['Amount']), 2)})
                    else:
                        key = i['Keys'][0].replace(replacestring, '')
                        row.update(
                            {key: round(float(i['Metrics']['AmortizedCost']['Amount']), 2)})
                else:
                    if str(i['Keys'][0]) in converted_regions.keys():
                        key = converted_regions[str(i['Keys'][0])]
                        if (tag == 'Purpose' and Style != 'Developer'):
                            service = i['Keys'][1].replace(replacestring, '')
                        else:
                            service = i['Keys'][1]
                        key = str(key) + '|' + str(service)
                        row.update(
                            {key: round(float(i['Metrics']['AmortizedCost']['Amount']), 2)})
            rows.append(row)
        '''
            converting the json data to dataframe
        '''
        df = pd.DataFrame(rows)
        df[tag] = pd.to_datetime(df[tag]).dt.strftime('%b-%Y')
        df = df.fillna(0.0)
        type = 'table'
        df = df.T
        df = df.reset_index()
        if (tag != 'date' and tag != 'Purpose') or (tag == 'Purpose' and Style == 'Developer'):
            df = df.rename(columns=df.iloc[0]).drop(df.index[0])
        if tag == 'date' or (tag == 'Purpose' and Style != 'Developer'):
            new_header = df.iloc[0]
            df = df[1:]
            df.columns = new_header
            df[['Region', 'Service']] = df[tag].str.split('|', expand=True)
            df = df.drop([tag], axis=1)
            cols = list(df.columns)
            cols = [cols[-1]] + cols[:-1]
            cols = [cols[-1]] + cols[:-1]
            df = df[cols]
            df.sort_values(by=['Region', 'Service'], ascending=[
                           True, True], inplace=True)
        if tag == 'Customer' and Style == 'Service':
            df[['Customers', 'Service']] = df[tag].str.split(
                '|', expand=True)
            df = df.drop([tag], axis=1)
            cols = list(df.columns)
            cols = [cols[-1]] + cols[:-1]
            cols = [cols[-1]] + cols[:-1]
            df = df[cols]
            df.sort_values(by=['Customers', 'Service'], ascending=[
                           True, True], inplace=True)
        if tag == 'Purpose' and Style == 'Developer':
            df = df.loc[df['Purpose'].isin(
                ['DeveloperApp', 'BatchJob', 'Mavis', 'DeveloperPlatform', 'V2APILogs'])]
        if tag == 'ConnectorIdentifier':
            df = df.loc[~df['ConnectorIdentifier'].isin(['Non-Connectors'])]
        self.reports.append({'Name': Name, 'Data': df, 'Type': type})

    def get_results(self, resp: boto3.resources.response, param='ResultsByTime', **kwargs):
        '''
        common boto3 API calls logc to get response and format in list of json objects 
        '''
        results = []
        try:
            response = resp(**kwargs)
            if response:
                # pprint(response)
                results.extend(response[param])
                while 'NextPageToken' in response:
                    next_token = response['NextPageToken']
                    print('\n NextPageToken:', next_token)
                    response = resp(**kwargs, NextPageToken=next_token)
                    results.extend(response[param])
        except ClientError as c:
            print(c)
        except Exception as e:
            print(e)
        return results

    def linked_acc_costType(self,
                            regions=['Singapore', 'Mumbai',
                                     'US East', 'Global'],
                            GroupBy=[
                                {"Type": "TAG", "Key": "CostType"},
                            ],
                            ):
        self.tagstart = (datetime.date.today() -
                         relativedelta(months=+3)).replace(day=1)
        self.threemonth = (datetime.date.today()).replace(day=1)
        globalDimensions = [
            {
                "Dimensions": {
                    "Key": "LINKED_ACCOUNT",
                    "Values": ["128241259851"]
                }
            },
            # {
            #     "Dimensions": {
            #         "Key": "REGION",
            #         "Values": ["ap-south-1", ]
            #         "Values": ['ap-southeast-1']
            #     }
            # },
            {
                "Not": {
                    "Dimensions": {
                        "Key": "RECORD_TYPE",
                        "Values": ["Tax", "Credit", "Refund", "Upfront", "Support", "Other out-of-cycle charges"]
                    }
                }
            },
            {
                'Tags': {
                    'Key': 'CostType',
                    'Values': [
                        'Global', 'Region'
                    ],
                }
            },
        ]

        names_to_regions = dict(map(reversed, self.region_to_names.items()))

        # self.tagstart = '2021-05-01'
        # self.threemonth = '2021-06-01'

        data = []
        data1 = {}
        for region in regions:
            if region != 'Global':
                Dimensions = {
                    'And': [*globalDimensions, {
                        "Dimensions": {
                            "Key": "REGION",
                            "Values": [names_to_regions[region]]
                        }
                    }, ]
                }
            else:
                Dimensions = {
                    'And': globalDimensions
                }

            results = self.get_results(self.client.get_cost_and_usage, 'ResultsByTime',
                                       TimePeriod={
                                           'Start': self.tagstart.isoformat(),
                                           'End': self.threemonth.isoformat()
                                       },
                                       Granularity='MONTHLY',
                                       Metrics=[
                                           'NetAmortizedCost',
                                       ],
                                       GroupBy=GroupBy,
                                       Filter=Dimensions,)

            # self.save_to_file(f'Tags/test2-results-{region}', results)
            # results = self.read_from_file(f'Tags/test2-results-{region}')
            for result in results:
                start_date = datetime.datetime.strptime(
                    result['TimePeriod']['Start'], '%Y-%m-%d').strftime('%b-%Y')
                for x in result['Groups']:
                    net_amortized_cost = round(
                        float(x['Metrics']['NetAmortizedCost']['Amount']), 2)
                    if 'Region' in x['Keys'][0] and region != 'Global':
                        data.append(
                            {'CostType Tag': f'Region, {region}', 'Total Amount': net_amortized_cost, start_date: net_amortized_cost})
                        break
                    elif ('Global' in x['Keys'][0]) and region == 'Global':
                        data.append(
                            {'CostType Tag': f'{region}', 'Total Amount': net_amortized_cost, start_date: net_amortized_cost})
        '''
            converting the json data to dataframe
        '''
        df = pd.DataFrame(data)
        df = df.fillna(0.0)
        columns = list(df.columns)
        columns.remove('Total Amount')
        columns.append('Total Amount')
        df = df.groupby(['CostType Tag']).sum()
        df = df.reset_index()
        df = df.reindex(columns=columns)
        _type = 'table'
        self.reports.append(
            {'Name': '128241259851-rolling 3 mth cost', 'Data': df, 'Type': _type})

    def get_all_services(self):
        end = self.end.isoformat()
        # six
        start = (datetime.date.today() - relativedelta(months=+6)
                 ).replace(day=1).isoformat()
        # end = datetime.datetime.now().date().isoformat()
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': start,
                                       'End': end
                                       # 'Start':'2021-01-01',
                                       # 'End':'2021-07-30'
                                   },
                                   Granularity='MONTHLY',
                                   Metrics=[
                                       'NetAmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=[{
                                            'Type': 'DIMENSION',
                                            'Key': 'SERVICE'
                                            }],
                                   Filter={
                                       "Not": {
                                           "Dimensions": {
                                               "Key": "RECORD_TYPE",
                                               "Values": ["Tax", "Credit", "Refund", "Upfront", "Support", "Other out-of-cycle charges"]
                                           }
                                       }
                                   }
                                   )
        # self.save_to_file('all_services_dev/all_service_results_dec_jul', results)
        all_services = []
        services_list = [
            'Amazon Relational Database Service',
            'Amazon Elastic Compute Cloud - Compute',
            'Amazon Elasticsearch Service',
            'EC2 - Other',
            'Amazon ElastiCache',
            'Amazon Simple Storage Service',
            'Amazon Elastic Load Balancing',
            'Amazon Simple Queue Service',
            'AmazonCloudWatch',
            'Amazon Athena',
            'Amazon GuardDuty',
            'AWS Lambda',
            'Amazon DynamoDB',
            'Amazon CloudFront',
            'Amazon Virtual Private Cloud',
            'Amazon API Gateway',
            'Amazon Elastic Container Service',
            'Amazon Redshift',
            'Amazon Kinesis',
        ]
        for result in results:
            temp = {'Date': result['TimePeriod']['Start']}
            others = 0
            for service in result['Groups']:
                service_name = service['Keys'][0]
                cost = float(service['Metrics']['NetAmortizedCost']['Amount'])
                if service_name in services_list:
                    temp.update({service_name: round(cost, 6)})
                else:
                    others += round(cost, 6)

            temp.update({'Others': others})
            all_services.append(temp)
        '''
            converting the json data to dataframe
        '''
        try:
            df = pd.DataFrame(all_services)
            df = df.fillna(0.0)
            df['Date'] = pd.to_datetime(df['Date'])
            df = df.groupby(['Date']).mean()
            df = df.reset_index()
            df['Date'] = pd.to_datetime(df['Date']).dt.strftime('%b-%Y')
            df.set_index(['Date'], inplace=True)
            df = df.T
            df = df.reset_index()
            df.rename(columns={'index': 'Services'}, inplace=True)
        except TypeError as t:
            print(t)
        except KeyError as k:
            print(k)

        _type = 'table'
        self.reports.append(
            {'Name': 'Service-Total', 'Data': df, 'Type': _type})
        return df

    def generateExcel(self):
        '''
        Generate report from list of dataframes with ther respective sheet name
        '''
        os.chdir('./')
        writer = pd.ExcelWriter('report.xlsx', engine='xlsxwriter')
        for report in self.reports:
            report['Data'].to_excel(writer, sheet_name=report['Name'], index=0)
            worksheet = writer.sheets[report['Name']]
        writer.save()

    def sendemail(self, receiver_email, cc_email):
        '''
        send email with attachment of report
        '''
        subject = "AWS cost report"
        body = "Please find the AWS cost report attached."
        sender_email = "cloudcostreports@euphoricthought.com"

        password = "qisfxyumelzrtoxg"
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject
        if cc_email:
            message["Cc"] = ", ".join(cc_email)
        # message["Bcc"] = ", ".join(bcc_email)
        message.attach(MIMEText(body, "plain"))
        filename = "report.xlsx"
        with open(filename, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {filename}",
        )
        message.attach(part)
        text = message.as_string()
        server = smtplib.SMTP('smtp.gmail.com: 587')
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
        server.quit()


def main_handler(event=None, context=None):
    '''
    Generates following reports
      - Services
      - Customer
      - Customer,Services
      - Cluster
      - Regions,Service
      - Regions,Purpose
      - Developer Purpose
      - Connector
      - Linked Accounts
      - Cost and Usage Service

    on every Monday
    '''
    costexplorer = CostExplorer()
    # -------- monday ----------
    costexplorer.addReport(Name="Services", GroupBy=[
                           {"Type": "DIMENSION", "Key": "SERVICE"}], Style='Total')
    costexplorer.addTAGReport(Name="Customer".format('Accounts')[:31], GroupBy=[
                              {"Type": "TAG", "Key": "Customer"}], Style='Total', tag='Customer')
    costexplorer.addTAGReport(Name="Customer,Services".format('Accounts')[:31], GroupBy=[
                              {"Type": "TAG", "Key": "Customer"}, {"Type": "DIMENSION", "Key": "SERVICE"}], Style='Service', tag='Customer')
    costexplorer.addTAGReport(Name="{}".format('Cluster')[:31], GroupBy=[
                              {"Type": "TAG", "Key": "Cluster"}], Style='Total', tag='Cluster')
    costexplorer.addTAGReport(Name="{}".format('Regions,Service')[:31], GroupBy=[
                              {"Type": "DIMENSION", "Key": "REGION"}, {"Type": "DIMENSION", "Key": "SERVICE"}], Style='Total')
    costexplorer.addTAGReport(Name="{}".format('Regions,Purpose')[:31], GroupBy=[
                              {"Type": "DIMENSION", "Key": "REGION"}, {"Type": "TAG", "Key": "Purpose"}], Style='Total', tag='Purpose')
    costexplorer.addTAGReport(Name="Developer".format('Purpose')[:31], GroupBy=[
                              {"Type": "TAG", "Key": "Purpose"}], Style='Developer', tag='Purpose')
    costexplorer.addTAGReport(Name="Connector".format('Connector')[:31], GroupBy=[
                              {"Type": "TAG", "Key": "ConnectorIdentifier"}], Style='Connector', tag='ConnectorIdentifier')
    costexplorer.addReport(
        Name="Accounts-AWS", GroupBy=[{"Type": "DIMENSION", "Key": "LINKED_ACCOUNT"}], Style='Account')
    # ---------
    # Service supported value(s): Amazon Elastic Compute Cloud - Compute, Amazon Relational Database Service
    costexplorer.linked_acc_costType()

    costexplorer.get_all_services()

    costexplorer.generateExcel()

    receiver_email = "cloud-costs@leadsquared.com"
    cc_email = []
    costexplorer.sendemail(receiver_email, cc_email)

    receiver_email = 'bhalotia.vikas@gmail.com'
    cc_email = ['vikas@euphoricthought.com']
    costexplorer.sendemail(receiver_email, cc_email)


if __name__ == '__main__':
    main_handler()
