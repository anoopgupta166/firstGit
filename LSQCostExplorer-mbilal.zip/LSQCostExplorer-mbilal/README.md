# LSQCostExplorer

# Monday Report at 10 AM
    * File name: WEEKLY_COST_REPORT
    * Reports generated:
      - Services
      - Customer
      - Customer,Services
      - Cluster
      - Regions,Service
      - Regions,Purpose
      - Developer Purpose
      - Connector
      - Linked Accounts
      - Cost and Usage Service

# Friday Report at 10AM
    * WEEKLY_COST_REPORT_FRI
    * Reports generated:
      - RIRecommendation
      - Recent and Upcoming Ri expiries

# Capras and Converse Report at 8AM 
    * File name: capras_cnverse
    * only applies to capras client
    * Reports generated:
      - Converse Services with last two week data, pie chart for last week data
      - Capras Services with last two week data, pie chart for last week data

# Automation and SQS region every month on 2nd day report
    * File name: analyze_automation_costs

# timer automation
    * All services report generation on time is done with systemd timer, the respectivve files are stored in systemd folder.

# Code flow is as follows:
    * Having the desired input parameters like filters, services and regions
    * Getting the data from the boto3 API by passing the input
    * Formatting the data according to required fields and formates to work in dataframe
    * Adding to dataframe and Manupulating the data as required format.
    * adding the dataframe to report list and converting all to xlsx sheets.
    * sending the generated report to respective email Ids.
  