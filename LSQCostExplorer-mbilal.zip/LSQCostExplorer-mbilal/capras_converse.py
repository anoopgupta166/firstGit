#!/usr/bin/python3
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import smtplib
import boto3
from botocore.exceptions import ClientError
import json
import os
import pandas as pd
import numpy as np
from dateutil.relativedelta import relativedelta
import datetime
from itertools import zip_longest
TARGET_REGION = 'ap-south-1'


class Main:
    def __init__(self):
        now = datetime.datetime.now()
        self.end = datetime.date.today()
        # start of week
        self.start = (self.end-relativedelta(days=+14)).isoformat()
        self.start_week_no = int(datetime.datetime.strptime(
            self.start, '%Y-%m-%d').strftime('%V'))
        # end of week
        self.end = self.end.isoformat()

        self.capras_converse = {}
        self.converse = {}
        self.reports = []
        self.global_filter = self.params_to_dict(
            TimePeriod={
                'Start': self.start,
                'End': self.end
            },
            Granularity='DAILY',
            Metrics=[
                'AmortizedCost',
                'UnblendedCost',
            ],
            GroupBy=[{
                'Type': 'DIMENSION',
                'Key': 'SERVICE'
            }],
            Filter={
                'And': [
                    {
                        "Dimensions": {
                            "Key": "LINKED_ACCOUNT",
                            "Values": ["877124996003"]
                        }
                    },
                    {
                        'Dimensions': {
                            "Key": "REGION",
                            "Values": [
                                "ap-south-1", "ap-southeast-1",
                                "us-east-1", ]
                        }
                    },
                ]
            }
        )
        '''
        # Ca(u,s,m) = Ca_Co(u,s,m) - Co(u) * 3
        df['capras'] = df['capras_converse'] - df['converse'] * 3
        drop df['capras_converse']

        '''

        self.client = boto3.client('ce', region_name=TARGET_REGION)

    def params_to_dict(self, **kwargs):
        return kwargs

    def get_results(self, resp: boto3.resources.response, param='ResultsByTime', **kwargs):
        results = []
        try:
            response = resp(**kwargs)
            if response:
                results.extend(response[param])
                while 'NextPageToken' in response:
                    next_token = response['NextPageToken']
                    # print('\n NextPageToken:',next_token)
                    response = resp(**kwargs, NextPageToken=next_token)
                    results.extend(response[param])
        except ClientError as c:
            print(c)
        except Exception as e:
            print(e)
        return results

    def save_to_file(self, name, response):
        with open(f'{name}.json', 'w+') as f:
            f.write(json.dumps(response))

    def read_from_file(self, name):
        with open(f'{name}.json', 'r+') as f:
            res = (json.load(f))
        return res

    def generate_excel(self, filename):
        writer = pd.ExcelWriter(filename, engine='xlsxwriter')
        workbook = writer.book
        for report in self.reports:
            x = 0
            worksheet = workbook.add_worksheet(report['Name'])
            writer.sheets[report['Name']] = worksheet

            bar_chart = workbook.add_chart(
                {'type': 'column'}  # , 'subtype': 'stacked'}
            )

            for df in report['Data']:
                print('x---:', x)
                df.to_excel(
                    writer, sheet_name=report['Name'], startrow=x, index=False)
# ---------------------------------------------------------------------

                chartend = len(df.columns) - 1
                print('chartend:', chartend)
                print('len(df)---:', len(df))

                row_num = x+len(df)
                bar_chart.add_series({
                    'name': [report['Name'], row_num, 0],
                    'categories': [report['Name'], 0, 1, 0, chartend],
                    'values':     [report['Name'], row_num, 1, row_num, chartend],

                })

                x += df.shape[0]+5
            bar_chart.set_title({'name': 'Column Chart'})
            bar_chart.set_y_axis({'label_position': 'low'})
            bar_chart.set_x_axis({'label_position': 'low'})
            worksheet.insert_chart(
                'A24', bar_chart, {'x_scale': 2.0, 'y_scale': 1.5})
# -------------------------------------------------------------
            pie_chart = workbook.add_chart(
                {'type': 'pie', 'subtype': 'percent_stacked'}
            )
            chartend = len(df.columns) - 2
            x = df.shape[0]+5
            print('chartend:', chartend)
            for row_num in range(x+1, x+len(df)):  # + 1):
                pie_chart.add_series({
                    'name':       [report['Name'], row_num, 0],
                    'categories': [report['Name'], 0, 1, 0, chartend],
                    'values':     [report['Name'], row_num, 1, row_num, chartend],
                    'data_labels': {'percentage': True, },
                })
            pie_chart.set_title({'name': 'Pie Chart'})
            pie_chart.set_y_axis({'label_position': 'low'})
            pie_chart.set_x_axis({'label_position': 'low'})
            worksheet.insert_chart(
                'R2', pie_chart, {'x_scale': 1.5, 'y_scale': 1.5})

        writer.save()

    def capras_all_services(self):
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                   },
                                   Granularity='DAILY',
                                   Metrics=[
                                       'AmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=[{
                                       'Type': 'DIMENSION',
                                       'Key': 'SERVICE'
                                   }],
                                   Filter={
                                       'And': [
                                           {
                                               "Dimensions": {
                                                   "Key": "LINKED_ACCOUNT",
                                                   "Values": ["877124996003"]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "REGION",
                                                   "Values": ["ap-south-1", "ap-southeast-1", "us-east-1", ]
                                               }
                                           },
                                           {
                                               'Tags': {
                                                   'Key': 'Purpose',
                                                   'Values': ['CAPRAS']
                                               }
                                           },
                                       ],
                                   },
                                   )
        self.save_to_file('capras_dev/all_service_results', results)
        capras = []
        for result in results:
            temp = {'Date': result['TimePeriod']['Start']}
            for service in result['Groups']:
                service_name = service['Keys'][0]
                cost = float(service['Metrics']['UnblendedCost']['Amount'])
                temp.update({service_name: round(cost, 6)})
                capras.append(temp)
        try:
            df = pd.DataFrame(capras)
            df = df.fillna(0.0)
            df = df.groupby(['Date']).mean()
            df = df.reset_index()

        except TypeError as t:
            print(t)
        print(df)
        # _type = 'table'
        # self.reports.append(
        #     {'Name': 'Capras All Services', 'Data': df, 'Type': _type})
        return df

    def converse_all_services(self):
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                   },
                                   Granularity='DAILY',
                                   Metrics=[
                                       'AmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=[{
                                       'Type': 'DIMENSION',
                                       'Key': 'SERVICE'
                                   }],
                                   Filter={
                                       'And': [
                                           {
                                               "Dimensions": {
                                                   "Key": "LINKED_ACCOUNT",
                                                   "Values": ["877124996003"]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "REGION",
                                                   "Values": [
                                                       "ap-south-1", "ap-southeast-1",
                                                       "us-east-1", ]
                                               }
                                           },
                                           {
                                               'Tags': {
                                                   'Key': 'Purpose',
                                                   'Values': ['Converse']
                                               }
                                           },
                                       ],
                                   },
                                   )
        # self.save_to_file('converse_dev/all_service_results', results)
        extra_service_results = self.__converse_extra_services()
        converse = []

        mismatch = []
        req_services = {
            'Amazon Elasticsearch Service': 0,
            'Amazon Kinesis': 0,
            'AWS CodePipeline': 0,
            'Amazon Elastic Load Balancing': 0,
            'Amazon ElastiCache': 0,
            'Amazon DynamoDB': 0,
            'Amazon CloudFront': 0,
            'CodeBuild': 0,
            'Amazon Simple Storage Service': 0,
        }
        req_e_services = [
            'AWS Key Management Service',
            'AWS Secrets Manager',
            'AWS Systems Manager',
            'Amazon EC2 Container Registry (ECR)',
            'EC2 - Other',
            'Amazon Elastic Compute Cloud - Compute',
            'Amazon Elastic Container Service'

        ]
        for result, result_e in zip_longest(results, extra_service_results):
            temp_dict = {}
            if result['TimePeriod']['Start'] != result_e['TimePeriod']['Start']:
                mismatch.append(
                    {result['TimePeriod']['Start']: result_e['TimePeriod']['Start']})
            temp_dict['Date'] = result['TimePeriod']['Start']
            for service, service_e in zip_longest(result['Groups'], result_e['Groups']):
                if service:
                    service_name = service['Keys'][0]
                    cost = float(service['Metrics']['UnblendedCost']['Amount'])
                    if service_name in list(req_services.keys()):
                        temp_dict.update({service_name: round(cost, 5)})
                    # req_services[service]+=cost
                if service_e:
                    service_name = service_e['Keys'][0]
                    cost = float(service_e['Metrics']
                                 ['UnblendedCost']['Amount'])
                    if service_name in req_e_services:
                        temp_dict.update({service_name: round(cost, 5)})
                    if 'Amazon Elastic Container Service' == service_name:
                        print('cost:', cost)

                # print(temp_dict)
                converse.append(temp_dict)
        self.save_to_file('converse_dev/converse_temp_dict', converse)

        try:
            df = pd.DataFrame(converse)
            df = df.fillna(0.0)
            df = df.groupby(['Date']).mean()

            df = df.reset_index()

            '''
            CodeBuild,CodePipeline,EC2 ContainerService
            '''
        except TypeError as t:
            print(t)
        print(df)
        # _type = 'table'
        # self.reports.append(
        #     {'Name': 'Converse All Services', 'Data': df, 'Type': _type})
        return df

    def __converse_extra_services(self):
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                   },
                                   Granularity='DAILY',
                                   Metrics=[
                                       'AmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=[{
                                            'Type': 'DIMENSION',
                                            'Key': 'SERVICE'
                                            }],
                                   Filter={
                                       "And": [

                                           {
                                               "Dimensions": {
                                                   "Key": "LINKED_ACCOUNT",
                                                   "Values": ["877124996003"]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "REGION",
                                                   "Values": ["ap-south-1", "ap-southeast-1", "us-east-1", ]
                                               }
                                           },
                                       ]
                                   }
                                   )

        # self.save_to_file(
        #     'converse_dev/extra_service_results', results)
        return results

    def converse_capras_cloudwatch_services(self):
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                   },
                                   Granularity='DAILY',
                                   Metrics=[
                                       'AmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=[{
                                       'Type': 'DIMENSION',
                                       'Key': 'SERVICE'
                                   }],
                                   Filter={
                                       'And': [
                                           {
                                               "Dimensions": {
                                                   "Key": "LINKED_ACCOUNT",
                                                   "Values": ["877124996003"]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "REGION",
                                                   "Values": [
                                                       "ap-south-1", "ap-southeast-1",
                                                       "us-east-1", ]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "SERVICE",
                                                   "Values": ['AmazonCloudWatch']

                                               }
                                           },

                                       ],
                                   },
                                   )
        # self.save_to_file(
        #     'converse_dev/cloudWatch_service_capras_and_converse_results', results)
        return results

    def converse_cloudwatch_services(self):
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                   },
                                   Granularity='DAILY',
                                   Metrics=[
                                       'AmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=[{
                                       'Type': 'DIMENSION',
                                       'Key': 'SERVICE'
                                   }],
                                   Filter={
                                       'And': [
                                           {
                                               "Dimensions": {
                                                   "Key": "LINKED_ACCOUNT",
                                                   "Values": ["877124996003"]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "REGION",
                                                   "Values": [
                                                       # "ap-south-1", "ap-southeast-1",
                                                       "us-east-1", ]
                                               }
                                           },
                                           {
                                               'Dimensions': {
                                                   "Key": "SERVICE",
                                                   "Values": ['AmazonCloudWatch']

                                               }
                                           },

                                       ],
                                   },

                                   )
        # self.save_to_file(
        #     'converse_dev/cloudWatch_service_converse_results', results)
        return results

    def capras_converse_cloudWatch_df(self):
        capras_converse_cloudwatch = self.converse_capras_cloudwatch_services()
        converse_cloudwatch = self.converse_cloudwatch_services()
        capras_converse_cw = []
        mismatch = []
        for result_cc, result_c in zip_longest(capras_converse_cloudwatch, converse_cloudwatch):
            temp_dict = {}
            if result_cc['TimePeriod']['Start'] != result_c['TimePeriod']['Start']:
                mismatch.append(result_cc['TimePeriod']['Start'])
            temp_dict['Date'] = result_cc['TimePeriod']['Start']
            temp_dict['Services'] = []
            for service_cc, service_c in zip_longest(result_cc['Groups'], result_c['Groups']):
                temp_dict['Services'].append({
                    'service_name': service_cc['Keys'][0],
                    'capras_converse_amount': service_cc['Metrics']['UnblendedCost']['Amount'],
                    'converse_amount': service_c['Metrics']['UnblendedCost']['Amount']
                })
            capras_converse_cw.append(temp_dict)
        print('mismatch:', mismatch)

        try:
            df = pd.json_normalize(capras_converse_cw, 'Services', ['Date'])
            # df['Date'] = pd.to_datetime(df['Date']).dt.tz_convert(None)
            df['capras_converse_amount'] = df['capras_converse_amount'].astype(
                float)
            df['converse_amount'] = df['converse_amount'].astype(float)
            df['converse_amount'] = df['converse_amount']*3
            df['capras_amount'] = df['capras_converse_amount'] - \
                df['converse_amount']
            first_column = df.pop('Date')
            df.insert(0, 'Date', first_column)

        except TypeError as t:
            print(t)
        print(df)
        print(mismatch)
        _type = 'table'
        # self.reports.append(
        #     {'Name': 'Capras and Converse cloudWatch', 'Data': df, 'Type': _type})
        return df

    def merge_capras_converse_cloudwatch(self, capras, converse, cloud_watch):
        print(cloud_watch)
        capras = pd.merge(
            capras, cloud_watch[['Date', 'capras_amount']], on='Date')
        capras.rename(
            columns={'capras_amount': 'AmazonCloudWatch'}, inplace=True)
        if 'AmazonCloudWatch' in converse.columns:
            converse.pop('AmazonCloudWatch')
        converse = pd.merge(
            converse, cloud_watch[['Date', 'converse_amount']], on='Date')
        converse.rename(
            columns={'converse_amount': 'AmazonCloudWatch'}, inplace=True)

        converse_l = np.array_split(converse, 2)
        capras_l = np.array_split(capras, 2)
        for i, conv in enumerate(converse_l):
            column_total = f'Week {self.start_week_no+i}'
            conv.loc[column_total] = conv.sum(axis=0)
            # 'Column_Total'
            conv.iloc[-1, conv.columns.get_loc('Date')
                      ] = column_total
            conv.loc[:, 'Row_Total'] = conv.sum(axis=1)

        for i, cap in enumerate(capras_l):
            # 'Column_Total' string
            column_total = f'Week {self.start_week_no+i}'
            cap.loc[column_total] = cap.sum(axis=0)
            cap.iloc[-1, cap.columns.get_loc('Date')
                     ] = column_total
            cap.loc[:, 'Row_Total'] = cap.sum(axis=1)

        _type = 'chart'
        self.reports.append(
            {'Name': 'Converse All Services', 'Data': converse_l, 'Type': _type})
        self.reports.append(
            {'Name': 'Capras All Services', 'Data': capras_l, 'Type': _type})
        return capras, converse

    def sendemail(self, receiver_email, cc_email):
        subject = "AWS capras converse report"
        body = "Please find the AWS cost report attached."
        sender_email = "cloudcostreports@euphoricthought.com"

        password = "qisfxyumelzrtoxg"
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject
        if cc_email:
            message["Cc"] = ", ".join(cc_email)
        # message["Bcc"] = ", ".join(bcc_email)
        message.attach(MIMEText(body, "plain"))
        filename = "capras_converse_report.xlsx"
        with open(filename, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {filename}",
        )
        message.attach(part)
        text = message.as_string()
        server = smtplib.SMTP('smtp.gmail.com: 587')
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
        server.quit()


test = Main()
# test.converse_capras_cloudwatch_services()
# test.converse_cloudwatch_services()
capras_df = test.capras_all_services()
converse_df = test.converse_all_services()
cloud_watch_df = test.capras_converse_cloudWatch_df()
# try:
test.merge_capras_converse_cloudwatch(
    capras_df, converse_df, cloud_watch_df)
test.generate_excel('capras_converse_report.xlsx')


receiver_email = 'sudhakar@leadsquared.com'
cc_email = ['ben.imchen@leadsquared.com,'
            'sukhbir.kalsi@leadsquared.com',
            'rohan.reddy@leadsquared.com',
            'himanshu@leadsquared.com',
            'vimal.stan@leadsquared.com']
test.sendemail(receiver_email, cc_email)

receiver_email = 'bhalotia.vikas@gmail.com'
cc_email = ['vikas@euphoricthought.com']
test.sendemail(receiver_email, cc_email)


# except Exception as e:
#     print('error:', e)
