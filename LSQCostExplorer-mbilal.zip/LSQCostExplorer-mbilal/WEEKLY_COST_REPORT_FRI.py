#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

import datetime
import logging
import pandas as pd
import numpy as np
import boto3
from botocore.exceptions import ClientError
import xlsxwriter
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dateutil.relativedelta import relativedelta, SU
import json

__author__ = " M Bilal k"
__version__ = "0.1.2"

TARGET_REGION = 'ap-south-1'


class CostExplorer:

    regions = ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
               'us-gov-east-1', 'us-gov-west-1',
               'sa-east-1',
               'ca-central-1',
               'eu-central-1', 'eu-west-1', 'eu-west-2', 'eu-south-1', 'eu-west-3', 'eu-north-1',
               'af-south-1',
               'me-south-1',
               'cn-north-1', 'cn-northwest-1',
               'ap-east-1', 'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1',
               ]

    def __init__(self):
        self.reports = []
        self.client = boto3.client('ce', region_name=TARGET_REGION)
        satdate = datetime.datetime.now() + relativedelta(weekday=SU(-1))
        self.end = satdate.date()
        self.start = (self.end - relativedelta(days=+84))

    # Call with Savings True to get Utilization report in dollar savings

    def addRiReport(self, Name='RICoverage', Savings=False, PaymentOption='PARTIAL_UPFRONT', Service='Amazon Elastic Compute Cloud - Compute'):
        type = 'chart'  # other option table

        if Name == 'RIRecommendation':
            '''
            RiRecommendationn from last 60days with 1 year of service time 
            '''

            services = {"Amazon Elastic Compute Cloud - Compute": 'ECC',
                        "Amazon Relational Database Service": 'RDS',
                        "Amazon Redshift": 'Redshift',
                        "Amazon ElastiCache": 'ElastiCache',
                        "Amazon Elasticsearch Service": 'Elasticsearch'
                        }
            for Service in services.keys():
                results = []

                try:
                    '''
                    Get data from boto3 API
                    '''
                    response = self.client.get_reservation_purchase_recommendation(
                        # AccountId='string', May use for Linked view
                        LookbackPeriodInDays='SIXTY_DAYS',
                        TermInYears='ONE_YEAR',
                        # PaymentOption=PaymentOption,
                        Service=Service
                    )
                    results.extend(response['Recommendations'])
                    # print(results)
                    while 'nextToken' in response:
                        nextToken = response['nextToken']
                        response = self.client.get_reservation_purchase_recommendation(
                            # AccountId='string', May use for Linked view
                            LookbackPeriodInDays='SIXTY_DAYS',
                            TermInYears='ONE_YEAR',
                            # PaymentOption=PaymentOption,
                            Service=Service,
                            NextPageToken=nextToken
                        )
                        results.extend(response['Recommendations'])

                        if 'nextToken' in response:
                            nextToken = response['nextToken']
                        else:
                            nextToken = False
                except Exception as c:
                    print(c)
                '''
                Format and filtering the results
                '''
                rows = []
                for i in results:
                    for v in i['RecommendationDetails']:
                        row = v['InstanceDetails'][list(
                            v['InstanceDetails'].keys())[0]]
                        row['Recommended'] = v['RecommendedNumberOfInstancesToPurchase']
                        row['Minimum'] = v['MinimumNumberOfInstancesUsedPerHour']
                        row['Maximum'] = v['MaximumNumberOfInstancesUsedPerHour']
                        row['Savings'] = v['EstimatedMonthlySavingsAmount']
                        row['OnDemand'] = v['EstimatedMonthlyOnDemandCost']
                        row['BreakEvenIn'] = v['EstimatedBreakEvenInMonths']
                        row['UpfrontCost'] = v['UpfrontCost']
                        row['MonthlyCost'] = v['RecurringStandardMonthlyCost']
                        rows.append(row)
                '''
                adding results to dataframe and filternimg, manupulating the data to requirments
                '''
                df = pd.DataFrame(rows)
                df['Savings'] = df['Savings'].astype(float)
                df = df[df['Savings'] >= 10.0]
                df = df.fillna(0.0)
                df['Recommended'] = pd.to_numeric(df['Recommended'])
                df = df.sort_values(by=['Recommended'])
                # df.set_index("Recommended", inplace=True)
                type = 'table'  # Dont try chart this
                df = df.T
                df = df.reset_index()
                df = df.T
                self.reports.append(
                    {'Name': f'RiRec-{services[Service]}', 'Data': df, 'Type': type})

        else:
            # ----------------------
            '''
            Get Ri Expired or going to expire in 3 months
                for EC2, RDS, RedShift, ElasticCache, ElasticSearch

            '''
            ec2, rds, red, ec, es = [], [], [], [], []
            for region in self.regions:
                for filter_value in ['active', 'retired']:
                    # print('*'*30, region, '*'*30)
                    try:
                        # ec2
                        ec2_client = boto3.client('ec2', region_name=region)

                        ec2_filtered_list, ec2_head, ec2_df = self.getExpRIList(ec2_client.describe_reserved_instances(
                            Filters=[{'Name': 'state', 'Values': [filter_value]}]),
                            'ReservedInstances',
                            'State',
                            filter_value,
                            ['ReservedInstancesId', 'Start', 'State', 'End',
                             'InstanceType', 'InstanceCount', 'ProductDescription'], region)
                        if not isinstance(ec2_df, list):
                            ec2.append(ec2_df)

                        # rds
                        rds_client = boto3.client('rds', region_name=region)

                        rds_filtered_list, rds_head, rds_df = self.getExpRIList(rds_client.describe_reserved_db_instances(),
                                                                                'ReservedDBInstances',
                                                                                'State',
                                                                                filter_value,
                                                                                ['ReservedDBInstanceId', 'StartTime', 'State', 'End',
                                                                                 'DBInstanceClass', 'DBInstanceCount'], region)
                        if not isinstance(rds_df, list):
                            rds.append(rds_df)

                        # redshift
                        red_client = boto3.client(
                            'redshift', region_name=region)

                        red_filtered_list, red_head, red_df = self.getExpRIList(red_client.describe_reserved_nodes(),
                                                                                'ReservedNodes',
                                                                                'State',
                                                                                filter_value,
                                                                                ['ReservedNodeId', 'StartTime', 'State', 'End',
                                                                                 'NodeType', 'NodeCount'], region)
                        if not isinstance(red_df, list):
                            red.append(red_df)

                        # elasticache
                        ec_client = boto3.client(
                            'elasticache', region_name=region)

                        ec_filtered_list, ec_head, ec_df = self.getExpRIList(ec_client.describe_reserved_cache_nodes(),
                                                                             'ReservedCacheNodes',
                                                                             'State',
                                                                             filter_value,
                                                                             ['ReservedCacheNodeId', 'StartTime', 'State', 'End',
                                                                              'CacheNodeType', 'CacheNodeCount'], region)
                        if not isinstance(ec_df, list):
                            ec.append(ec_df)

                        # elasticsearch
                        es_client = boto3.client('es', region_name=region)

                        es_filtered_list, es_head, es_df = self.getExpRIList(es_client.describe_reserved_elasticsearch_instances(),
                                                                             'ReservedElasticsearchInstances',
                                                                             'State',
                                                                             filter_value,
                                                                             ['ReservationName', 'ReservedElasticsearchInstanceId',
                                                                              'StartTime', 'State', 'End', 'ElasticsearchInstanceType',
                                                                              'ElasticsearchInstanceCount'], region)
                        if not isinstance(es_df, list):
                            es.append(es_df)

                    except ClientError as c:
                        print('*'*30, region, '*'*30)
                        print(c)
                # print(ec2)
                # ec2_state.append(ec2)
            ec2_df = pd.concat(ec2)
            ec2_df = ec2_df.sort_values('End')
            self.reports.append(
                {'Name': f'EC2Instances', 'Data': ec2_df})
            rds_df = pd.concat(rds)
            rds_df = rds_df.sort_values('End')
            self.reports.append(
                {'Name': f'RDSInstances', 'Data': rds_df})
            if len(red) > 0:
                red_df = pd.concat(red)
                self.reports.append(
                    {'Name': f'RedshiftNodes', 'Data': red_df})
            es_df = pd.concat(es)
            es_df = es_df.sort_values('End')
            self.reports.append(
                {'Name': f'ElasticsearchInstances', 'Data': es_df})
            ec_df = pd.concat(ec)
            ec_df = ec_df.sort_values('End')
            self.reports.append(
                {'Name': f'ElasticCacheNodes', 'Data': ec_df})
            # ----------------------

    def getExpRIList(self, response: boto3.resources.response, response_name, filter_name, filter_value, select_column=[], region=None):
        '''
        Get expired Ri list
        '''
        if len(response[response_name]) <= 0:
            print("Empty : " + response_name)
            return [], [], []

        if filter_value == 'retired':
            end = np.datetime64(self.end)
            start = self.end - relativedelta(months=1)
            start = np.datetime64(start)
            # end = '2021-05-27T11:27:23.495197'
            # start = '2021-01-20T11:27:23.495197'
        else:
            start = np.datetime64(self.end)
            end = np.datetime64(
                self.end + relativedelta(months=1))
            # start = '2021-05-20T11:27:23.495197'
            # end = '2021-09-27T11:27:23.495197'

        # print(end)
        # print(start)
        print("Exist : " + response_name)

        if response_name == 'ReservedInstances':
            '''
            Handle EC2 data that differe from other Ri services
            '''
            ec2_ri_list = list(
                map(lambda a: a.values(), response['ReservedInstances']))

            ec2_df = pd.json_normalize(response['ReservedInstances'])
            # ec2_df.drop_duplicates(subset=['Start'], keep=False, inplace=True)
            # print(ec2_df.Start)
            ec2_df['Start'] = pd.to_datetime(
                ec2_df['Start']).dt.tz_convert(None)
            ec2_df['End'] = pd.to_datetime(ec2_df['End']).dt.tz_convert(None)
            ec2_will_expire = ec2_df[(
                start <= ec2_df['End']) & (ec2_df['End'] <= end)]

            ec2_filtered_list = ec2_will_expire[select_column].values.tolist()
            if select_column:
                ec2_will_expire = ec2_will_expire.reindex(
                    columns=select_column)

            ec2_will_expire['region'] = region

            return ec2_filtered_list, ec2_will_expire[select_column].columns.to_list(), ec2_will_expire

        df = pd.json_normalize(response[response_name])

        df['StartTime'] = pd.to_datetime(df['StartTime']).dt.tz_convert(None)
        df['End'] = df['StartTime'] + pd.to_timedelta(df['Duration'], 's')
        # will_expire = df[df['End'] <= end]
        # will_expire = will_expire[start <= will_expire['End']]
        will_expire = df[(start <= df['End']) & (df['End'] <= end)]

        filtered_list = will_expire[select_column].values.tolist()
        if select_column:
            will_expire = will_expire.reindex(columns=select_column)

        will_expire['region'] = region

        return filtered_list, will_expire[select_column].columns.to_list(), will_expire

    def generateExcel(self, filename):
        '''
        Generate report from list of dataframes with ther respective sheet name
        '''
        os.chdir('./')
        writer = pd.ExcelWriter(filename, engine='xlsxwriter')
        for report in self.reports:
            report['Data'].to_excel(writer, sheet_name=report['Name'], index=0)
            worksheet = writer.sheets[report['Name']]
        writer.save()

    def sendemail(self, filename, receiver_email, cc_email, subject="AWS Ri report"):
        '''
        send email with attachment of report
        '''
        body = "Please find the AWS cost report attached."
        sender_email = "cloudcostreports@euphoricthought.com"

        password = "qisfxyumelzrtoxg"
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject
        if cc_email:
            message["Cc"] = ", ".join(cc_email)
        # message["Bcc"] = ", ".join(bcc_email)
        message.attach(MIMEText(body, "plain"))

        with open(filename, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {filename}",
        )
        message.attach(part)
        text = message.as_string()
        server = smtplib.SMTP('smtp.gmail.com: 587')
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
        server.quit()


def main_handler(event=None, context=None):
    '''
    Generate :
        Ri Recommendation 
        Recen and upcomming expiring RI Services

    on every friday

    '''
    costexplorer = CostExplorer()

    # Service supported value(s): Amazon Elastic Compute Cloud - Compute, Amazon Relational Database Service
    # -------- friday --------
    today_date = datetime.date.today()
    costexplorer.addRiReport(Name="RIRecommendation")
    costexplorer.generateExcel('Ri_recomm_report.xlsx')

    receiver_email = "SRE@leadsquared.com"
    cc_email = []
    costexplorer.sendemail(
        'Ri_recomm_report.xlsx', receiver_email, cc_email, f"Ri Recommendation - {today_date}")

    receiver_email = 'bhalotia.vikas@gmail.com'
    cc_email = ['vikas@euphoricthought.com']
    costexplorer.sendemail('Ri_recomm_report.xlsx', receiver_email,
                           cc_email, f"Ri Recommendation - {today_date}")

    # -----------------------
    costexplorer.reports = []

    costexplorer.addRiReport()
    costexplorer.generateExcel('Ri_exp_report.xlsx')

    receiver_email = "SRE@leadsquared.com"
    cc_email = []
    costexplorer.sendemail(
        'Ri_exp_report.xlsx', receiver_email, cc_email, f"Recent and Upcoming Ri expiries - {today_date}")

    receiver_email = 'bhalotia.vikas@gmail.com'
    cc_email = ['vikas@euphoricthought.com']
    costexplorer.sendemail(
        'Ri_exp_report.xlsx', receiver_email, cc_email, f"Recent and Upcoming Ri expiries - {today_date}")

    # -------------------

    # --------


if __name__ == '__main__':
    main_handler()
