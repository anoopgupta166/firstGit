from pprint import pprint
import os
import boto3
from botocore.exceptions import ClientError
import datetime
import json
import pandas as pd


TARGET_REGION = 'ap-south-1'


TARGET_REGION = 'ap-south-1'


class Main:
    regions = ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
               'us-gov-east-1', 'us-gov-west-1',
               'sa-east-1',
               'ca-central-1',
               'eu-central-1', 'eu-west-1', 'eu-west-2', 'eu-south-1', 'eu-west-3', 'eu-north-1',
               'af-south-1',
               'me-south-1',
               'cn-north-1', 'cn-northwest-1',
               'ap-east-1', 'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-southeast-1', 'ap-southeast-2', 'ap-northeast-1',
               ]

    def __init__(self):
        now = datetime.datetime.now()
        # end_date=now + relativedelta(weekday=MO(-1))
        # start_date = end_date - relativedelta(days=+7)
        self.start = '2020-12-28'
        # self.start = '2021-05-28'
        # self.start = start_date.date().isoformat()
        self.end = '2021-07-04'
        self.client = boto3.client('ce', region_name=TARGET_REGION)
        self.reports = []

    def save_to_file(self, name, response):
        with open(f'{name}.json', 'w+') as f:
            # f.write(json.dumps(response))
            f.write(json.dumps(response, default=str))

    def read_from_file(self, name):
        with open(f'{name}.json', 'r+') as f:
            res = (json.load(f))
        return res

    def get_results(self, resp: boto3.resources.response, param='ResultsByTime', **kwargs):
        results = []
        pprint(kwargs)
        try:
            response = resp(**kwargs)
            if response:
                # pprint(response)
                results.extend(response[param])
                while 'NextPageToken' in response:
                    next_token = response['NextPageToken']
                    print('\n NextPageToken:', next_token)
                    response = resp(**kwargs, NextPageToken=next_token)
                    results.extend(response[param])
        except ClientError as c:
            print(c)
        except Exception as e:
            print(e)
        return results

    def generateExcel(self, filename):

        writer = pd.ExcelWriter(f'{filename}.xlsx', engine='xlsxwriter')
        for report in self.reports:
            report['Data'].to_excel(writer, sheet_name=report['Name'], index=0)
            worksheet = writer.sheets[report['Name']]
        writer.save()


def ri_db_analysis(main):

    response_name = 'ReservedDBInstances'
    filter_value = 'active'
    response_list = []
    for region in main.regions:
        try:
            rds_client = boto3.client('rds', region_name=region)
            response = rds_client.describe_reserved_db_instances()

            # print(response)
            for obj in response[response_name]:
                obj['Region'] = region

            response_list.extend(response[response_name])
        except Exception as e:
            print(e)
    try:
        # print(response_list)
        df = pd.json_normalize(response_list)
        df['StartTime'] = pd.to_datetime(df['StartTime']).dt.tz_convert(None)
        df['EndTime'] = df['StartTime'] + pd.to_timedelta(df['Duration'], 's')
        x = df[df["State"] == "active"]
        # print(x)

        y = x.reindex(columns=['ReservedDBInstancesOfferingId', 'ReservedDBInstanceId',
                      'StartTime', 'EndTime', 'ProductDescription', 'Region'])
        z = df.reindex(columns=['ReservedDBInstancesOfferingId', 'ReservedDBInstanceId',
                       'DBInstanceClass', 'DBInstanceCount', 'ProductDescription'])
    except Exception as e:
        print(e)
    print(y)
    main.reports.append(
        {'Name': f'RiDBInstance', 'Data': y})
    main.reports.append(
        {'Name': f'RiDBInstanceSize', 'Data': z})


if __name__ == '__main__':
    main = Main()
    ri_db_analysis(main)
    main.generateExcel(f'RiDBInstances_all')
