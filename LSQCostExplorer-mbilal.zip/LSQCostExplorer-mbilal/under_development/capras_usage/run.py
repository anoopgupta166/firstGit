from utils import read_credentails
from reading_emails_scripts import get_mail_attachments, get_unseen_emails
import json


def get_email_body(messages):
    if messages:
        x = []
        # print(*messages,'\n')
        for message in messages:
            body = message.get_payload()[0].get_payload()
            body = body.replace('=\r\n', '')
            body = body.replace('\r\n', '')
            x.append(body)
        return x
        # attachments = get_mail_attachments(message,
        #                                    lambda x: x.endswith('.json'))
        # for attachment in attachments:
        #     if attachment:
        #         with open('./data/json_files/{}'.format(attachment[0]), 'wb') as file:
        #             file.write(attachment[1])


def get_json_from_body(email_bodies):
    # return email_bodies
    for x in email_bodies:
        print(type(x))
        print(x.strip())
        print('-'*30)
        try:
            json_object = json.loads(x.strip())
            print(json_object)

            return json_object

        except ValueError as e:
            print(e)


if __name__ == "__main__":
    email_address, password = read_credentails()
    messages = get_unseen_emails(email_address, password)
    email_bodies = get_email_body(messages)
    # print(*email_bodies)
    print(email_bodies)
    print(get_json_from_body(email_bodies))
