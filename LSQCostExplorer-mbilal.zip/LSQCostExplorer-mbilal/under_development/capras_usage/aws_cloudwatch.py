import json
from pprint import pprint
import boto3
from datetime import datetime
boto3.setup_default_session(profile_name='prodaccess')
client = boto3.client('cloudwatch')

#  aws cloudwatch list-dashboards --profile prodaccess
'''
        {
            "DashboardName": "CAPRAS-7d-Usage",
            "DashboardArn": "arn:aws:cloudwatch::877124996003:dashboard/CAPRAS-7d-Usage",
            "LastModified": "2021-06-21T02:07:17Z",
            "Size": 8637
        },
'''


def save_to_file(name, response):
    with open(f'aws_cloudwatch/{name}.json', 'w+') as f:
        f.write(json.dumps(response))


def get_metric():
    response = client.get_metric_statistics(
        Namespace='string',
        MetricName='string',
        Dimensions=[
            {
                'Name': 'string',
                'Value': 'string'
            },
        ],
        StartTime=datetime(2021, 1, 1),
        EndTime=datetime(2021, 5, 1),
        Period=123,

        Statistics=[
            'SampleCount' | 'Average' | 'Sum' | 'Minimum' | 'Maximum',
            'SampleCount'
        ],
        ExtendedStatistics=[
            'string',
        ],
        Unit='Seconds' | 'Microseconds' | 'Milliseconds' | 'Bytes' | 'Kilobytes' | 'Megabytes' | 'Gigabytes' | 'Terabytes' | 'Bits' | 'Kilobits' | 'Megabits' | 'Gigabits' | 'Terabits' | 'Percent' | 'Count' | 'Bytes/Second' | 'Kilobytes/Second' | 'Megabytes/Second' | 'Gigabytes/Second' | 'Terabytes/Second' | 'Bits/Second' | 'Kilobits/Second' | 'Megabits/Second' | 'Gigabits/Second' | 'Terabits/Second' | 'Count/Second' | 'None'
    )


def list_metric():
    response = client.list_metrics(
        Namespace='string',
        MetricName='string',
        Dimensions=[
            {
                'Name': 'string',
                'Value': 'string'
            },
        ],
        NextToken='string',
        RecentlyActive='PT3H'
    )
    print(response)


def get_metric_data():
    response = client.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'string',
                'MetricStat': {
                    'Metric': {
                        'Namespace': 'string',
                        'MetricName': 'string',
                        'Dimensions': [
                            {
                                'Name': 'string',
                                'Value': 'string'
                            },
                        ]
                    },
                    'Period': 123,
                    'Stat': 'string',
                    'Unit': 'Seconds' | 'Microseconds' | 'Milliseconds' | 'Bytes' | 'Kilobytes' | 'Megabytes' | 'Gigabytes' | 'Terabytes' | 'Bits' | 'Kilobits' | 'Megabits' | 'Gigabits' | 'Terabits' | 'Percent' | 'Count' | 'Bytes/Second' | 'Kilobytes/Second' | 'Megabytes/Second' | 'Gigabytes/Second' | 'Terabytes/Second' | 'Bits/Second' | 'Kilobits/Second' | 'Megabits/Second' | 'Gigabits/Second' | 'Terabits/Second' | 'Count/Second' | 'None'
                },
                'Expression': 'string',
                'Label': 'string',
                'ReturnData': True | False,
                'Period': 123,
                'AccountId': 'string'
            },
        ],
        StartTime=datetime(2015, 1, 1),
        EndTime=datetime(2015, 1, 1),
        NextToken='string',
        ScanBy='TimestampDescending' | 'TimestampAscending',
        MaxDatapoints=123,
        LabelOptions={
            'Timezone': 'string'
        }
    )


def put_metric_data():
    response = client.put_metric_data(
        Namespace='string',
        MetricData=[
            {
                'MetricName': 'string',
                'Dimensions': [
                    {
                        'Name': 'string',
                        'Value': 'string'
                    },
                ],
                'Timestamp': datetime(2015, 1, 1),
                'Value': 123.0,
                'StatisticValues': {
                    'SampleCount': 123.0,
                    'Sum': 123.0,
                    'Minimum': 123.0,
                    'Maximum': 123.0
                },
                'Values': [
                    123.0,
                ],
                'Counts': [
                    123.0,
                ],
                'Unit': 'Seconds' | 'Microseconds' | 'Milliseconds' | 'Bytes' | 'Kilobytes' | 'Megabytes' | 'Gigabytes' | 'Terabytes' | 'Bits' | 'Kilobits' | 'Megabits' | 'Gigabits' | 'Terabits' | 'Percent' | 'Count' | 'Bytes/Second' | 'Kilobytes/Second' | 'Megabytes/Second' | 'Gigabytes/Second' | 'Terabytes/Second' | 'Bits/Second' | 'Kilobits/Second' | 'Megabits/Second' | 'Gigabits/Second' | 'Terabits/Second' | 'Count/Second' | 'None',
                'StorageResolution': 123
            },
        ]
    )


def list_dashboards():
    result = []
    response = client.list_dashboards(
        DashboardNamePrefix='CAPRA',
    )
    result.append(response)
    while response.get('NextToken'):
        response = client.list_dashboards(
            DashboardNamePrefix='CAPRA',
            NextToken=response['NextToken']
        )
        result.append(response)

    pprint(result)

# aws cloudwatch get-dashboard --dashboard-name="CAPRAS-7d-Usage" --profile prodaccess


def get_dashboard():
    result = []
    response = client.get_dashboard(
        DashboardName='CAPRAS-7d-Usage',
    )
    result.append(response['DashboardBody'])
    while response.get('NextToken'):
        response = client.get_dashboard(
            DashboardName='CAPRAS-7d-Usage',
            NextToken=response['NextToken']
        )
        result.append(response['DashboardBody'])

    res = json.loads(result[0])
    pprint(res)
    save_to_file('usage_cloudwatch_dashboard', res)


def save_to_file(name, response):
    # with open('accounts.py', 'w+') as f:
    #     f.write(str(accounts))
    with open(f'{name}.json', 'w+') as f:
        # f.write(json.dumps(response[0], default=str))
        f.write(json.dumps(response, default=str))
        # f.write(json.dumps(dict(response[0]), default=str))
        # f.write(response)


# list_dashboards()

# get_dashboard()

# get_metric()


def read_from_file(name):
    with open(f'{name}.json', 'r+') as f:
        res = (json.load(f))
    return res


def test():
    x = read_from_file('usage_cloudwatch_1')
    pprint(x)


# test()


def get_metric():
    response = client.get_metric_statistics(
        Namespace='ApiGateway',
        MetricName='5XXError',
        Dimensions=[
            {
                'Name': 'string',
                'Value': 'string'
            },
        ],
        StartTime=datetime(2021, 1, 1),
        EndTime=datetime(2021, 5, 1),
        Period=123,
        Statistics=[
            'SampleCount' | 'Average' | 'Sum' | 'Minimum' | 'Maximum',
            'SampleCount'
        ],
        ExtendedStatistics=[
            'string',
        ],
        Unit='Seconds' | 'Microseconds' | 'Milliseconds' | 'Bytes' | 'Kilobytes' | 'Megabytes' | 'Gigabytes' | 'Terabytes' | 'Bits' | 'Kilobits' | 'Megabits' | 'Gigabits' | 'Terabits' | 'Percent' | 'Count' | 'Bytes/Second' | 'Kilobytes/Second' | 'Megabytes/Second' | 'Gigabytes/Second' | 'Terabytes/Second' | 'Bits/Second' | 'Kilobits/Second' | 'Megabits/Second' | 'Gigabits/Second' | 'Terabits/Second' | 'Count/Second' | 'None'
    )


def t_list_metric():
    response = client.list_metrics(
        Namespace='AWS/ApiGateway',
        # MetricName='5XXError',
        # Dimensions=[
        #     {
        #         'Name': 'prod-APSO1-CAPRAS-API',
        #         'Value': ''
        #     },
        # ],
        # NextToken='string',
        # RecentlyActive='PT3H'

    )
    save_to_file('all_cloudwaatch_metrics', response)
    print(response)


def t_get_metric():
    response = client.get_metric_statistics(
        # Namespace='ApiGateway',
        # MetricName='5XXError',
        # Dimensions=[
        #     {
        #         'Name': 'Resource',
        #         'Value': '/1/api/telephony/logcallcomplete/{ConnectorHostKey}/{InstanceID}'
        #     },
        # ],

        Namespace="AWS/ApiGateway",
        MetricName="Count",
        # MetricName="IntegrationLatency",
        Dimensions=[
            # {
            #     "Name": "ApiName",
            #     "Value": "prod-APSO1-CAPRAS-API"
            # },
            # {
            #     "Name": "Resource",
            #     "Value": "/activity/create"
            # },
            # {
            #     "Name": "Stage",
            #     "Value": "prod"
            # },
            # {
            #     "Name": "Method",
            #     "Value": "POST"
            # }
            # {
            #     'Name': 'Resource',
            #     'Value': '/1/api/telephony/logcallcomplete/{ConnectorHostKey}/{InstanceID}'
            # },
            # {
            #     "Name": "ApiName",
            #     "Value": "prod-APSO1-CAPRAS-API"
            # },
            # {
            #     "Name": "Resource",
            #     "Value": "/1/api/telephony/logcallcomplete/status"
            # },
            # {
            #     "Name": "Stage",
            #     "Value": "prod"
            # },
            # {
            #     "Name": "Method",
            #     "Value": "GET"
            # }
        ],
        StartTime=datetime(2021, 9, 1),
        EndTime=datetime(2021, 9, 5),
        # Period=2400,
        Period=300,
        Statistics=[
            # 'SampleCount' | 'Average' | 'Sum' | 'Minimum' | 'Maximum',
            # 'SampleCount'
            'Sum'
        ],
        # ExtendedStatistics=[
        #     'string',
        # ],
        # Unit='Seconds'
        Unit='Count'
    )
    print(response)
    save_to_file('apigateway_count_1', response)


# def t_get_metric():
#     response = client.get_metric_statistics(
#         # Namespace='ApiGateway',
#         # MetricName='5XXError',
#         # Dimensions=[
#         #     {
#         #         'Name': 'Resource',
#         #         'Value': '/1/api/telephony/logcallcomplete/{ConnectorHostKey}/{InstanceID}'
#         #     },
#         # ],

#         Namespace="AWS/ApiGateway",
#         MetricName="5XXError",
#         # Dimensions=[
#         #     {
#         #         "Name": "ApiName",
#         #         "Value": "prod-APSO1-CAPRAS-API"
#         #     },
#         #     {
#         #         "Name": "Resource",
#         #         "Value": "/activity/create"
#         #     },
#         #     {
#         #         "Name": "Stage",
#         #         "Value": "prod"
#         #     },
#         #     {
#         #         "Name": "Method",
#         #         "Value": "POST"
#         #     }
#         # ],
#         StartTime=datetime(2021, 9, 1),
#         EndTime=datetime(2021, 9, 5),
#         # Period=2400,
#         Period=300,
#         Statistics=[
#             # 'SampleCount' | 'Average' | 'Sum' | 'Minimum' | 'Maximum',
#             # 'SampleCount'
#             'Sum'
#         ],
#         # ExtendedStatistics=[
#         #     'string',
#         # ],
#         # Unit='Seconds'
#         Unit='Count'
#     )
#     print(response)
#     save_to_file('apigateway_count_1', response)
t_list_metric()
# t_get_metric()

'''
aws cloudwatch list-metrics --namespace "AWS/ApiGateway" --profile=prodaccess >> aws_cloudwatch.json
aws cloudwatch get-metric-statistics --namespace AWS/ApiGateway --metric-name Count --start-time 2021-09-03T23:00:00Z --end-time 2021-09-05T23:00:00Z --period 300 --statistics Sum --profile=prodaccess
'''

