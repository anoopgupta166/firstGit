#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

import datetime
import logging
import pandas as pd
import numpy as np
import boto3
from botocore.exceptions import ClientError
import xlsxwriter
import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dateutil.relativedelta import relativedelta, SU
import json

__author__ = "Ravi Petlur, M Bilal k"
__version__ = "0.1.1"

TARGET_REGION = 'ap-south-1'


class AutomationExplorer:
    region_to_names = {
        "us-east-2": "US East (Ohio)",
        "us-east-1": "US East (N. Virginia)",
        "ap-southeast-1": "Asia Pacific (Singapore)",
        "ap-south-1": "Asia Pacific (Mumbai)",
        "eu-west-1": "Europe (Ireland)",
        "eu-north-1": "Europe (Stockholm)"
    }

    def __init__(self):
        self.reports = []
        self.end = datetime.datetime.now().date().isoformat()
        self.start = (datetime.datetime.now().date() - relativedelta(days=+
                                                                     84)).replace(day=1).isoformat()
        print(self.start, self.end, type(self.start))
        self.client = boto3.client('ce', region_name=TARGET_REGION)
        # satdate = datetime.datetime.now() + relativedelta(weekday=SU(-1))
        # self.end = satdate.date()
        # self.start = (self.end - relativedelta(days=+84))

    def save_to_file(self, name, response):
        with open(f'analyze_automation_cost/{name}_1.json', 'w+') as f:
            f.write(json.dumps(response))

    def get_results(self, resp: boto3.resources.response, param='ResultsByTime', **kwargs):
        '''
        common boto3 API calls logc to get response and format in list of json objects 
        '''
        results = []
        try:
            response = resp(**kwargs)
            if response:
                # print(response)
                results.extend(response[param])
                while 'NextPageToken' in response:
                    next_token = response['NextPageToken']
                    print('\n NextPageToken:', next_token)
                    response = resp(**kwargs, NextPageToken=next_token)
                    results.extend(response[param])
        except ClientError as c:
            print(c)
        except Exception as e:
            print(e)
        return results

    def generateExcel(self):
        os.chdir('./analyze_automation_cost')
        writer = pd.ExcelWriter('automation_report.xlsx', engine='xlsxwriter')
        for report in self.reports:
            report['Data'].to_excel(writer, sheet_name=report['Name'], index=0)
            worksheet = writer.sheets[report['Name']]
        writer.save()

    def sendemail(self, receiver_email, cc_email):
        print(os.getcwd())
        subject = "AWS cost report"
        body = "Please find the AWS cost report attached."
        sender_email = "cloudcostreports@euphoricthought.com"
        password = "qisfxyumelzrtoxg"

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject
        if cc_email:
            message["Cc"] = ", ".join(cc_email)
        # message["Bcc"] = ", ".join(bcc_email)
        message.attach(MIMEText(body, "plain"))
        filename = "automation_report.xlsx"
        with open(filename, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {filename}",
        )
        message.attach(part)
        text = message.as_string()
        server = smtplib.SMTP('smtp.gmail.com: 587')
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, text)
        server.quit()

    def sqs_region(self):
        globalDimensions = [
            {
                "Dimensions": {
                    "Key": "LINKED_ACCOUNT",
                    "Values": ["128241259851"]
                }
            },
            {
                "Dimensions": {
                    "Key": "SERVICE",
                    "Values": ["Amazon Simple Queue Service"]
                }
            },

        ]

        groupBy = [{
            'Type': 'DIMENSION',
            'Key': 'REGION'
        }]

        start = ''
        end = ''
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                       #    'Start': '2021-06-01',
                                       #    'End': '2021-08-01'
                                   },
                                   Granularity='MONTHLY',
                                   Metrics=[
                                       'NetAmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=groupBy,
                                   Filter={'And':
                                           globalDimensions}
                                   )

        # print(results)
        self.save_to_file('sqs_region', results)
        sqs_region = []
        for result in results:
            temp = {'Date': result['TimePeriod']['Start']}
            for service in result['Groups']:
                region = service['Keys'][0]
                if region in self.region_to_names.keys():
                    region = self.region_to_names[region]

                cost = float(service['Metrics']['UnblendedCost']['Amount'])
                if cost > 0.1:
                    temp.update({region: round(cost, 6)})
                    sqs_region.append(temp)

        try:
            df = pd.DataFrame(sqs_region)
            df = df.fillna(0.0)
            df = df.groupby(['Date']).mean()
            # df = df.reset_index()
            df = df.T
            df = df.reset_index()
            df.rename(columns={'index': 'Services'}, inplace=True)
        except TypeError as t:
            print(t)
        print(df.head())
        _type = 'table'
        self.reports.append({'Name': 'SQS', 'Data': df, 'Type': _type})

    def automation_agent_service(self):
        groupBy = [{
            "Type": "TAG", "Key": "Customer"
        }]
        results = self.get_results(self.client.get_cost_and_usage,
                                   TimePeriod={
                                       'Start': self.start,
                                       'End': self.end
                                       #    'Start': '2021-06-01',
                                       #    'End': '2021-08-01'
                                   },
                                   Granularity='MONTHLY',
                                   Metrics=[
                                       'NetAmortizedCost',
                                       'UnblendedCost',
                                   ],
                                   GroupBy=groupBy,
                                   Filter={
                                       'Tags': {
                                           'Key': 'AppCategory',
                                           'Values': [
                                               'AutomationAgentService'
                                           ],
                                       }
                                   },

                                   )

        # print(results)
        self.save_to_file('automation_agent_service', results)

        customers = []

        for result in results:
            temp = {'Date': result['TimePeriod']['Start']}
            for customer in result['Groups']:
                key = customer['Keys'][0].replace('Customer$', '')
                cost = float(customer['Metrics']['UnblendedCost']['Amount'])
                temp.update({key: round(cost, 6)})
                customers.append(temp)

        try:
            df = pd.DataFrame(customers)
            df = df.fillna(0.0)
            df = df.groupby(['Date']).mean()
            # df = df.reset_index()
            df = df.T
            df = df.reset_index()
            df.rename(columns={'index': 'Customers'}, inplace=True)
        except TypeError as t:
            print(t)
        print(df.head())
        _type = 'table'
        self.reports.append(
            {'Name': 'Automation_agent', 'Data': df, 'Type': _type})


def main():
    obj = AutomationExplorer()
    obj.sqs_region()
    obj.automation_agent_service()
    obj.generateExcel()

    receiver_email = 'automationcost@leadsquared.com'
    cc_email = []
    obj.sendemail(receiver_email, cc_email)

    receiver_email = 'bhalotia.vikas@gmail.com'
    cc_email = ['vikas@euphoricthought.com']
    obj.sendemail(receiver_email, cc_email)


if __name__ == '__main__':
    main()
